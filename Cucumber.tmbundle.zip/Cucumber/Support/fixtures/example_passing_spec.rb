describe "An example failing spec" do
  it "should pass" do
    true.should be_true
  end

  it "should pass too" do
    false.should be_false
  end
end
