$:.unshift(File.join(File.dirname(__FILE__), 'files'))
require 'base'
require 'feature_file'
require 'steps_file'
require 'step_detector'