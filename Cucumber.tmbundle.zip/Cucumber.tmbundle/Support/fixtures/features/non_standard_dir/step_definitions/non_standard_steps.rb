Given "non standard step" do
  
end