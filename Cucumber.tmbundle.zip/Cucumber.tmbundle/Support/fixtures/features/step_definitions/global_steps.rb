Given "global step" do
  Foo.should_not_error
end

Given "another global step" do
  
end
